# sdoosa-algo-trade-python

This project is mainly for newbies into algo trading who are interested in learning to code their own trading algo using python interpreter.

This is in the context of Indian stock exchanges and brokers.
